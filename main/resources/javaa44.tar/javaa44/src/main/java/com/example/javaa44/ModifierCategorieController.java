package com.example.javaa44;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import java.sql.SQLException;

public class ModifierCategorieController {
    @FXML private TextField nomField;
    @FXML private TextArea descriptionArea;

    private CategorieService categorieService = new CategorieService();
    private Categorie categorie;

    public void setCategorie(Categorie categorie) {
        this.categorie = categorie;
        populateFields();
    }

    private void populateFields() {
        if (categorie != null) {
            nomField.setText(categorie.getNom());
            descriptionArea.setText(categorie.getDescription());
        }
    }

    @FXML
    private void handleSave() {
        if (!validateInputs()) {
            return;
        }

        try {
            categorie.setNom(nomField.getText().trim());
            categorie.setDescription(descriptionArea.getText().trim());

            categorieService.updateCategorie(categorie);
            closeWindow();
        } catch (SQLException e) {
            showError("Erreur lors de la modification de la catégorie", e.getMessage());
        }
    }

    @FXML
    private void handleCancel() {
        closeWindow();
    }

    private boolean validateInputs() {
        if (nomField.getText().trim().isEmpty()) {
            showError("Erreur de validation", "Le nom de la catégorie est requis");
            nomField.requestFocus();
            return false;
        }

        if (descriptionArea.getText().trim().isEmpty()) {
            showError("Erreur de validation", "La description de la catégorie est requise");
            descriptionArea.requestFocus();
            return false;
        }

        return true;
    }

    private void closeWindow() {
        Stage stage = (Stage) nomField.getScene().getWindow();
        stage.close();
    }

    private void showError(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
} 
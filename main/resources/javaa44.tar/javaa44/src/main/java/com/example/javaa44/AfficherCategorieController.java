package com.example.javaa44;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Optional;

public class AfficherCategorieController {
    @FXML private TextField searchField;
    @FXML private TableView<Categorie> categorieTable;
    @FXML private TableColumn<Categorie, String> nomColumn;
    @FXML private TableColumn<Categorie, String> descriptionColumn;

    private ObservableList<Categorie> categories = FXCollections.observableArrayList();
    private CategorieService categorieService = new CategorieService();

    @FXML
    public void initialize() {
        try {
            loadCategories();
            setupTableColumns();
            setupSearch();
        } catch (SQLException e) {
            showError("Erreur lors du chargement des catégories", e.getMessage());
        }
    }

    private void loadCategories() throws SQLException {
        categories.clear();
        categories.addAll(categorieService.getAllCategories());
    }

    private void setupTableColumns() {
        nomColumn.setCellValueFactory(new PropertyValueFactory<>("nom"));
        descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
    }

    private void setupSearch() {
        FilteredList<Categorie> filteredData = new FilteredList<>(categories, b -> true);
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(categorie -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();
                return categorie.getNom().toLowerCase().contains(lowerCaseFilter) ||
                       categorie.getDescription().toLowerCase().contains(lowerCaseFilter);
            });
        });
        SortedList<Categorie> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(categorieTable.comparatorProperty());
        categorieTable.setItems(sortedData);
    }

    @FXML
    private void handleSearch() {
        // La recherche est déjà gérée par le listener sur searchField
    }

    @FXML
    private void handleAdd() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/javaa44/AjouterCategorie.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setTitle("Ajouter une Catégorie");
            stage.setScene(new Scene(root));
            stage.showAndWait();
            loadCategories();
        } catch (IOException | SQLException e) {
            showError("Erreur lors de l'ouverture du formulaire d'ajout", e.getMessage());
        }
    }

    @FXML
    private void handleEdit() {
        Categorie selectedCategorie = categorieTable.getSelectionModel().getSelectedItem();
        if (selectedCategorie == null) {
            showError("Erreur", "Veuillez sélectionner une catégorie à modifier");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/javaa44/ModifierCategorie.fxml"));
            Parent root = loader.load();
            ModifierCategorieController controller = loader.getController();
            controller.setCategorie(selectedCategorie);
            
            Stage stage = new Stage();
            stage.setTitle("Modifier la Catégorie");
            stage.setScene(new Scene(root));
            stage.showAndWait();
            loadCategories();
        } catch (IOException | SQLException e) {
            showError("Erreur lors de l'ouverture du formulaire de modification", e.getMessage());
        }
    }

    @FXML
    private void handleDelete() {
        Categorie selectedCategorie = categorieTable.getSelectionModel().getSelectedItem();
        if (selectedCategorie == null) {
            showError("Erreur", "Veuillez sélectionner une catégorie à supprimer");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation de suppression");
        alert.setHeaderText("Supprimer la catégorie");
        alert.setContentText("Êtes-vous sûr de vouloir supprimer cette catégorie ?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try {
                categorieService.deleteCategorie(selectedCategorie.getId());
                loadCategories();
            } catch (SQLException e) {
                showError("Erreur lors de la suppression", e.getMessage());
            }
        }
    }

    private void showError(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
} 
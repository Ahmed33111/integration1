package controllers;

import entities.Personne;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import services.ServicePersonne;

import java.io.IOException;
import java.sql.SQLException;

public class AjouterPersonneController {

    @FXML
    private TextField tfAge;
    @FXML
    private TextField tfNom;
    @FXML
    private TextField tfPrenom;
    @FXML
    private Button btnAjouter;
    @FXML
    private Button btnAfficher;

    private ServicePersonne servicePersonne;
    private Personne personneToEdit;
    private boolean isEditMode = false;

    @FXML
    void initialize() {
        servicePersonne = new ServicePersonne();
        
        // Ajouter des validateurs pour les champs
        tfAge.textProperty().addListener((obs, oldVal, newVal) -> {
            if (!newVal.matches("\\d*")) {
                tfAge.setText(newVal.replaceAll("[^\\d]", ""));
            }
        });
    }

    public void setPersonneToEdit(Personne personne) {
        this.personneToEdit = personne;
        this.isEditMode = true;
        
        // Remplir les champs avec les données de la personne
        tfNom.setText(personne.getNom());
        tfPrenom.setText(personne.getPrenom());
        tfAge.setText(String.valueOf(personne.getAge()));
        
        // Changer le texte du bouton
        btnAjouter.setText("Modifier");
    }

    @FXML
    void handleAfficher() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/AfficherPersonne.fxml"));
            Stage stage = (Stage) btnAfficher.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            showError("Erreur", "Impossible d'ouvrir la liste des personnes", e.getMessage());
        }
    }

    @FXML
    void handleAjouter() {
        if (validateInputs()) {
            try {
                int age = Integer.parseInt(tfAge.getText());
                String nom = tfNom.getText().trim();
                String prenom = tfPrenom.getText().trim();

                if (isEditMode && personneToEdit != null) {
                    personneToEdit.setNom(nom);
                    personneToEdit.setPrenom(prenom);
                    personneToEdit.setAge(age);
                    servicePersonne.modifier(personneToEdit);
                    showSuccess("Modification réussie", "La personne a été modifiée avec succès.");
                } else {
                    Personne personne = new Personne(age, nom, prenom);
                    servicePersonne.ajouter(personne);
                    showSuccess("Ajout réussi", "La personne a été ajoutée avec succès.");
                }
                
                // Fermer la fenêtre
                Stage stage = (Stage) btnAjouter.getScene().getWindow();
                stage.close();
                
            } catch (SQLException e) {
                showError("Erreur", "Erreur lors de l'opération", e.getMessage());
            }
        }
    }

    private boolean validateInputs() {
        StringBuilder errors = new StringBuilder();
        
        if (tfNom.getText().trim().isEmpty()) {
            errors.append("- Le nom est requis\n");
        }
        
        if (tfPrenom.getText().trim().isEmpty()) {
            errors.append("- Le prénom est requis\n");
        }
        
        if (tfAge.getText().trim().isEmpty()) {
            errors.append("- L'âge est requis\n");
        } else {
            try {
                int age = Integer.parseInt(tfAge.getText());
                if (age < 0 || age > 150) {
                    errors.append("- L'âge doit être compris entre 0 et 150\n");
                }
            } catch (NumberFormatException e) {
                errors.append("- L'âge doit être un nombre valide\n");
            }
        }
        
        if (errors.length() > 0) {
            showError("Erreur de validation", "Veuillez corriger les erreurs suivantes :", errors.toString());
            return false;
        }
        
        return true;
    }

    private void showError(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void showSuccess(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}

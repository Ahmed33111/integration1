package controllers;

import entities.Personne;
import entities.Publication;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import services.ServicePersonne;
import services.ServicePublication;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class AfficherPublicationController {
    @FXML
    private TableColumn<Publication, String> colContenu;
    @FXML
    private TableColumn<Publication, String> colDate;
    @FXML
    private TableColumn<Publication, String> colTitre;
    @FXML
    private TableColumn<Publication, String> colAuteur;
    @FXML
    private TableView<Publication> tvPublications;
    @FXML
    private Button btnAjouter;
    @FXML
    private Button btnModifier;
    @FXML
    private Button btnSupprimer;
    @FXML
    private Button btnCommentaires;

    private ServicePublication servicePublication = new ServicePublication();
    private ServicePersonne servicePersonne = new ServicePersonne();
    private Map<Integer, Personne> personnesMap = new HashMap<>();

    @FXML
    void initialize() {
        try {
            // Charger les personnes pour l'affichage des auteurs
            for (Personne p : servicePersonne.recuperer()) {
                personnesMap.put(p.getId(), p);
            }
            colTitre.setCellValueFactory(new PropertyValueFactory<>("titre"));
            colContenu.setCellValueFactory(new PropertyValueFactory<>("contenu"));
            colDate.setCellValueFactory(new PropertyValueFactory<>("date_publication"));
            // Afficher le nom complet de l'auteur
            colAuteur.setCellValueFactory(cellData -> {
                Publication pub = cellData.getValue();
                Personne pers = personnesMap.get(pub.getId_user());
                String nomComplet = pers != null ? pers.getNom() + " " + pers.getPrenom() : "Inconnu";
                return new javafx.beans.property.SimpleStringProperty(nomComplet);
            });
            refreshPublications();
            tvPublications.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
                boolean isSelected = newSelection != null;
                btnModifier.setDisable(!isSelected);
                btnSupprimer.setDisable(!isSelected);
                btnCommentaires.setDisable(!isSelected);
            });
            btnModifier.setDisable(true);
            btnSupprimer.setDisable(true);
            btnCommentaires.setDisable(true);
        } catch (SQLException e) {
            showError("Erreur", "Impossible de charger les publications", e.getMessage());
        }
    }

    private void refreshPublications() throws SQLException {
        ObservableList<Publication> publications = FXCollections.observableList(servicePublication.recuperer());
        tvPublications.setItems(publications);
    }

    @FXML
    void handleAjouterPublication() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/AjouterPublication.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setTitle("Nouvelle Publication");
            stage.setScene(new Scene(root));
            stage.showAndWait();
            refreshPublications();
        } catch (IOException e) {
            showError("Erreur", "Impossible d'ouvrir le formulaire d'ajout", e.getMessage());
        } catch (SQLException e) {
            showError("Erreur", "Impossible de rafraîchir les données", e.getMessage());
        }
    }

    @FXML
    void handleModifierPublication() {
        Publication selectedPublication = tvPublications.getSelectionModel().getSelectedItem();
        if (selectedPublication == null) {
            showWarning("Aucune sélection", "Veuillez sélectionner une publication à modifier.");
            return;
        }
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/AjouterPublication.fxml"));
            Parent root = loader.load();
            AjouterPublicationController controller = loader.getController();
            controller.setPublicationToEdit(selectedPublication);
            Stage stage = new Stage();
            stage.setTitle("Modifier Publication");
            stage.setScene(new Scene(root));
            stage.showAndWait();
            refreshPublications();
        } catch (IOException e) {
            showError("Erreur", "Impossible d'ouvrir le formulaire de modification", e.getMessage());
        } catch (SQLException e) {
            showError("Erreur", "Impossible de rafraîchir les données", e.getMessage());
        }
    }

    @FXML
    void handleSupprimerPublication() {
        Publication selectedPublication = tvPublications.getSelectionModel().getSelectedItem();
        if (selectedPublication == null) {
            showWarning("Aucune sélection", "Veuillez sélectionner une publication à supprimer.");
            return;
        }
        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Confirmation de suppression");
        confirmation.setHeaderText("Supprimer la publication");
        confirmation.setContentText("Êtes-vous sûr de vouloir supprimer cette publication ?\nTous les commentaires associés seront également supprimés.");
        Optional<ButtonType> result = confirmation.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try {
                servicePublication.supprimer(selectedPublication);
                refreshPublications();
                showSuccess("Succès", "La publication a été supprimée avec succès.");
            } catch (SQLException e) {
                showError("Erreur", "Impossible de supprimer la publication", e.getMessage());
            }
        }
    }

    @FXML
    void handleAfficherCommentaires() {
        Publication selectedPublication = tvPublications.getSelectionModel().getSelectedItem();
        if (selectedPublication == null) {
            showWarning("Aucune sélection", "Veuillez sélectionner une publication pour voir les commentaires.");
            return;
        }
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/AfficherCommentaire.fxml"));
            Parent root = loader.load();
            AfficherCommentaireController controller = loader.getController();
            controller.setPublication(selectedPublication);
            Stage stage = new Stage();
            stage.setTitle("Commentaires - " + selectedPublication.getTitre());
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            showError("Erreur", "Impossible d'ouvrir la vue des commentaires", e.getMessage());
        }
    }

    private void showError(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
    private void showWarning(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
    private void showSuccess(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}

package controllers;

import entities.Personne;
import entities.Publication;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import services.ServicePersonne;
import services.ServicePublication;

import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class AjouterPublicationController {
    @FXML
    private DatePicker dpDatePublication;
    @FXML
    private TextArea taContenu;
    @FXML
    private TextField tfTitre;
    @FXML
    private ComboBox<Personne> cbPersonne;
    @FXML
    private Button btnAjouter;
    @FXML
    private Button btnAnnuler;

    private Publication publicationToEdit;
    private boolean isEditMode = false;
    private ServicePublication servicePublication = new ServicePublication();
    private ServicePersonne servicePersonne = new ServicePersonne();

    @FXML
    void initialize() {
        dpDatePublication.setValue(LocalDate.now());
        chargerPersonnes();
    }

    private void chargerPersonnes() {
        try {
            List<Personne> personnes = servicePersonne.recuperer();
            ObservableList<Personne> obsList = FXCollections.observableArrayList(personnes);
            cbPersonne.setItems(obsList);
            cbPersonne.setCellFactory(param -> new ListCell<>() {
                @Override
                protected void updateItem(Personne item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? "" : item.getNom() + " " + item.getPrenom());
                }
            });
            cbPersonne.setButtonCell(new ListCell<>() {
                @Override
                protected void updateItem(Personne item, boolean empty) {
                    super.updateItem(item, empty);
                    setText(empty || item == null ? "" : item.getNom() + " " + item.getPrenom());
                }
            });
        } catch (SQLException e) {
            showError("Erreur", "Impossible de charger les personnes", e.getMessage());
        }
    }

    public void setPublicationToEdit(Publication publication) {
        this.publicationToEdit = publication;
        this.isEditMode = true;
        tfTitre.setText(publication.getTitre());
        taContenu.setText(publication.getContenu());
        if (publication.getDate_publication() != null) {
            dpDatePublication.setValue(publication.getDate_publication().toLocalDate());
        }
        // Sélectionner la personne correspondante
        chargerPersonnes();
        for (Personne p : cbPersonne.getItems()) {
            if (p.getId() == publication.getId_user()) {
                cbPersonne.getSelectionModel().select(p);
                break;
            }
        }
        btnAjouter.setText("Modifier");
    }

    @FXML
    void handleAjouter() {
        if (!validateInputs()) {
            return;
        }
        try {
            String titre = tfTitre.getText().trim();
            String contenu = taContenu.getText().trim();
            Date datePublication = Date.valueOf(dpDatePublication.getValue());
            Personne personne = cbPersonne.getValue();
            int userId = personne.getId();

            if (isEditMode && publicationToEdit != null) {
                publicationToEdit.setTitre(titre);
                publicationToEdit.setContenu(contenu);
                publicationToEdit.setDate_publication(datePublication);
                publicationToEdit.setId_user(userId);
                servicePublication.modifier(publicationToEdit);
                showSuccess("Succès", "La publication a été modifiée avec succès.");
            } else {
                Publication newPublication = new Publication(
                        titre,
                        contenu,
                        datePublication,
                        userId
                );
                servicePublication.ajouter(newPublication);
                showSuccess("Succès", "La publication a été ajoutée avec succès.");
            }
            Stage stage = (Stage) btnAjouter.getScene().getWindow();
            stage.close();
        } catch (SQLException e) {
            showError("Erreur", "Erreur lors de l'enregistrement", e.getMessage());
        }
    }

    @FXML
    void handleAnnuler() {
        Stage stage = (Stage) btnAnnuler.getScene().getWindow();
        stage.close();
    }

    private boolean validateInputs() {
        StringBuilder errors = new StringBuilder();
        if (tfTitre.getText().trim().isEmpty()) {
            errors.append("- Le titre est requis\n");
        }
        if (taContenu.getText().trim().isEmpty()) {
            errors.append("- Le contenu est requis\n");
        }
        if (dpDatePublication.getValue() == null) {
            errors.append("- La date est requise\n");
        }
        if (cbPersonne.getValue() == null) {
            errors.append("- L'auteur est requis\n");
        }
        if (errors.length() > 0) {
            showWarning("Erreur de validation", "Veuillez corriger les erreurs suivantes :", errors.toString());
            return false;
        }
        return true;
    }

    private void showError(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
    private void showWarning(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
    private void showSuccess(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}

package controllers;

import entities.Personne;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import services.ServicePersonne;

import java.io.IOException;
import java.sql.SQLException;

public class AfficherPersonneController {
    @FXML
    private TableColumn<Personne, Integer> colAge;
    @FXML
    private TableColumn<Personne, String> colNom;
    @FXML
    private TableView<Personne> tvPersonnes;
    @FXML
    private TableColumn<Personne, String> colPrenom;
    @FXML
    private Button btnAjouter;
    @FXML
    private Button btnModifier;
    @FXML
    private Button btnSupprimer;

    private ServicePersonne servicePersonne;

    @FXML
    void initialize() {
        servicePersonne = new ServicePersonne();
        try {
            ObservableList<Personne> observableList = FXCollections.observableList(servicePersonne.recuperer());
            tvPersonnes.setItems(observableList);
            colNom.setCellValueFactory(new PropertyValueFactory<>("nom"));
            colPrenom.setCellValueFactory(new PropertyValueFactory<>("prenom"));
            colAge.setCellValueFactory(new PropertyValueFactory<>("age"));
            
            // Activer/désactiver les boutons en fonction de la sélection
            tvPersonnes.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
                boolean isSelected = newSelection != null;
                btnModifier.setDisable(!isSelected);
                btnSupprimer.setDisable(!isSelected);
            });
            
            // Désactiver les boutons au démarrage
            btnModifier.setDisable(true);
            btnSupprimer.setDisable(true);
            
        } catch (SQLException e) {
            showError("Erreur", "Impossible de charger les données", e.getMessage());
        }
    }

    @FXML
    private void handleAjouter() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/AjouterPersonne.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setTitle("Ajouter une personne");
            stage.setScene(new Scene(root));
            stage.showAndWait();
            refreshTable();
        } catch (IOException e) {
            showError("Erreur", "Impossible d'ouvrir la fenêtre d'ajout", e.getMessage());
        }
    }

    @FXML
    private void handleModifier() {
        Personne selectedPersonne = tvPersonnes.getSelectionModel().getSelectedItem();
        if (selectedPersonne != null) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/AjouterPersonne.fxml"));
                Parent root = loader.load();
                AjouterPersonneController controller = loader.getController();
                controller.setPersonneToEdit(selectedPersonne);
                
                Stage stage = new Stage();
                stage.setTitle("Modifier une personne");
                stage.setScene(new Scene(root));
                stage.showAndWait();
                refreshTable();
            } catch (IOException e) {
                showError("Erreur", "Impossible d'ouvrir la fenêtre de modification", e.getMessage());
            }
        }
    }

    @FXML
    private void handleSupprimer() {
        Personne selectedPersonne = tvPersonnes.getSelectionModel().getSelectedItem();
        if (selectedPersonne != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation");
            alert.setHeaderText("Supprimer une personne");
            alert.setContentText("Êtes-vous sûr de vouloir supprimer cette personne ?");

            if (alert.showAndWait().get() == ButtonType.OK) {
                try {
                    servicePersonne.supprimer(selectedPersonne.getId());
                    refreshTable();
                } catch (SQLException e) {
                    showError("Erreur", "Impossible de supprimer la personne", e.getMessage());
                }
            }
        }
    }

    private void refreshTable() {
        try {
            ObservableList<Personne> observableList = FXCollections.observableList(servicePersonne.recuperer());
            tvPersonnes.setItems(observableList);
        } catch (SQLException e) {
            showError("Erreur", "Impossible de rafraîchir les données", e.getMessage());
        }
    }

    private void showError(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }
}

package com.example.javaa44;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.sql.SQLException;

public class ModifierPublicationController {
    @FXML private TextField titreField;
    @FXML private TextArea contenuField;
    @FXML private ComboBox<Categorie> categorieCombo;
    @FXML private ComboBox<User> userCombo;

    private Publication publication;
    private PublicationService publicationService = new PublicationService();
    private CategorieService categorieService = new CategorieService();
    private UserService userService = new UserService();

    public void setPublication(Publication publication) {
        this.publication = publication;
        populateFields();
    }

    @FXML
    public void initialize() {
        try {
            loadCategories();
            loadUsers();
        } catch (SQLException e) {
            showError("Erreur lors du chargement des données", e.getMessage());
        }
    }

    private void populateFields() {
        if (publication != null) {
            titreField.setText(publication.getTitre());
            contenuField.setText(publication.getContenu());
            categorieCombo.setValue(publication.getCategorie());
            userCombo.setValue(publication.getUser());
        }
    }

    private void loadCategories() throws SQLException {
        ObservableList<Categorie> categories = FXCollections.observableArrayList(categorieService.getAllCategories());
        categorieCombo.setItems(categories);
        categorieCombo.setCellFactory(param -> new ListCell<Categorie>() {
            @Override
            protected void updateItem(Categorie item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item.getNom());
                }
            }
        });
    }

    private void loadUsers() throws SQLException {
        ObservableList<User> users = FXCollections.observableArrayList(userService.getAllUsers());
        userCombo.setItems(users);
        userCombo.setCellFactory(param -> new ListCell<User>() {
            @Override
            protected void updateItem(User item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item.getNom() + " " + item.getPrenom());
                }
            }
        });
    }

    @FXML
    private void handleSave() {
        if (!validateInputs()) {
            return;
        }

        try {
            publication.setTitre(titreField.getText().trim());
            publication.setContenu(contenuField.getText().trim());
            publication.setCategorie(categorieCombo.getValue());
            publication.setUser(userCombo.getValue());

            publicationService.updatePublication(publication);
            closeWindow();
        } catch (SQLException e) {
            showError("Erreur lors de la modification de la publication", e.getMessage());
        }
    }

    @FXML
    private void handleCancel() {
        closeWindow();
    }

    private boolean validateInputs() {
        if (titreField.getText().trim().isEmpty()) {
            showError("Erreur de validation", "Le titre est obligatoire");
            return false;
        }
        if (contenuField.getText().trim().isEmpty()) {
            showError("Erreur de validation", "Le contenu est obligatoire");
            return false;
        }
        if (categorieCombo.getValue() == null) {
            showError("Erreur de validation", "Veuillez sélectionner une catégorie");
            return false;
        }
        if (userCombo.getValue() == null) {
            showError("Erreur de validation", "Veuillez sélectionner un utilisateur");
            return false;
        }
        return true;
    }

    private void closeWindow() {
        Stage stage = (Stage) titreField.getScene().getWindow();
        stage.close();
    }

    private void showError(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
} 
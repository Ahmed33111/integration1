package com.example.javaa44;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Optional;

public class AfficherPublicationController {
    @FXML private TextField searchField;
    @FXML private TableView<Publication> publicationTable;
    @FXML private TableColumn<Publication, String> titreColumn;
    @FXML private TableColumn<Publication, String> contenuColumn;
    @FXML private TableColumn<Publication, String> dateColumn;
    @FXML private TableColumn<Publication, String> categorieColumn;
    @FXML private TableColumn<Publication, String> userColumn;

    private ObservableList<Publication> publications = FXCollections.observableArrayList();
    private PublicationService publicationService = new PublicationService();

    @FXML
    public void initialize() {
        try {
            loadPublications();
            setupTableColumns();
            setupSearch();
        } catch (SQLException e) {
            showError("Erreur lors du chargement des publications", e.getMessage());
        }
    }

    private void loadPublications() throws SQLException {
        publications.clear();
        publications.addAll(publicationService.getAllPublications());
    }

    private void setupTableColumns() {
        titreColumn.setCellValueFactory(new PropertyValueFactory<>("titre"));
        contenuColumn.setCellValueFactory(new PropertyValueFactory<>("contenu"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        categorieColumn.setCellValueFactory(cellData -> 
            cellData.getValue().getCategorie() != null ? 
            cellData.getValue().getCategorie().getNom() : null);
        userColumn.setCellValueFactory(cellData -> 
            cellData.getValue().getUser() != null ? 
            cellData.getValue().getUser().getNom() : null);
    }

    private void setupSearch() {
        FilteredList<Publication> filteredData = new FilteredList<>(publications, b -> true);
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(publication -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();
                return publication.getTitre().toLowerCase().contains(lowerCaseFilter) ||
                       publication.getContenu().toLowerCase().contains(lowerCaseFilter);
            });
        });
        SortedList<Publication> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(publicationTable.comparatorProperty());
        publicationTable.setItems(sortedData);
    }

    @FXML
    private void handleSearch() {
        // La recherche est déjà gérée par le listener sur searchField
    }

    @FXML
    private void handleAdd() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/javaa44/AjouterPublication.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setTitle("Ajouter une Publication");
            stage.setScene(new Scene(root));
            stage.showAndWait();
            loadPublications();
        } catch (IOException | SQLException e) {
            showError("Erreur lors de l'ouverture du formulaire d'ajout", e.getMessage());
        }
    }

    @FXML
    private void handleEdit() {
        Publication selectedPublication = publicationTable.getSelectionModel().getSelectedItem();
        if (selectedPublication == null) {
            showError("Erreur", "Veuillez sélectionner une publication à modifier");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/javaa44/ModifierPublication.fxml"));
            Parent root = loader.load();
            ModifierPublicationController controller = loader.getController();
            controller.setPublication(selectedPublication);
            
            Stage stage = new Stage();
            stage.setTitle("Modifier la Publication");
            stage.setScene(new Scene(root));
            stage.showAndWait();
            loadPublications();
        } catch (IOException | SQLException e) {
            showError("Erreur lors de l'ouverture du formulaire de modification", e.getMessage());
        }
    }

    @FXML
    private void handleDelete() {
        Publication selectedPublication = publicationTable.getSelectionModel().getSelectedItem();
        if (selectedPublication == null) {
            showError("Erreur", "Veuillez sélectionner une publication à supprimer");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation de suppression");
        alert.setHeaderText("Supprimer la publication");
        alert.setContentText("Êtes-vous sûr de vouloir supprimer cette publication ?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try {
                publicationService.deletePublication(selectedPublication.getId());
                loadPublications();
            } catch (SQLException e) {
                showError("Erreur lors de la suppression", e.getMessage());
            }
        }
    }

    private void showError(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
} 
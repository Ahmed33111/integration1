package com.example.javaa44;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Optional;

public class AfficherCommentaireController {
    @FXML private TextField searchField;
    @FXML private TableView<Commentaire> commentaireTable;
    @FXML private TableColumn<Commentaire, String> contenuColumn;
    @FXML private TableColumn<Commentaire, String> dateColumn;
    @FXML private TableColumn<Commentaire, String> userColumn;
    @FXML private TableColumn<Commentaire, String> publicationColumn;

    private ObservableList<Commentaire> commentaires = FXCollections.observableArrayList();
    private CommentaireService commentaireService = new CommentaireService();

    @FXML
    public void initialize() {
        try {
            loadCommentaires();
            setupTableColumns();
            setupSearch();
        } catch (SQLException e) {
            showError("Erreur lors du chargement des commentaires", e.getMessage());
        }
    }

    private void loadCommentaires() throws SQLException {
        commentaires.clear();
        commentaires.addAll(commentaireService.getAllCommentaires());
    }

    private void setupTableColumns() {
        contenuColumn.setCellValueFactory(new PropertyValueFactory<>("contenu"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        userColumn.setCellValueFactory(new PropertyValueFactory<>("user"));
        publicationColumn.setCellValueFactory(new PropertyValueFactory<>("publication"));
    }

    private void setupSearch() {
        FilteredList<Commentaire> filteredData = new FilteredList<>(commentaires, b -> true);
        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredData.setPredicate(commentaire -> {
                if (newValue == null || newValue.isEmpty()) {
                    return true;
                }
                String lowerCaseFilter = newValue.toLowerCase();
                return commentaire.getContenu().toLowerCase().contains(lowerCaseFilter) ||
                       commentaire.getUser().toLowerCase().contains(lowerCaseFilter) ||
                       commentaire.getPublication().toLowerCase().contains(lowerCaseFilter);
            });
        });
        SortedList<Commentaire> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(commentaireTable.comparatorProperty());
        commentaireTable.setItems(sortedData);
    }

    @FXML
    private void handleSearch() {
        // La recherche est déjà gérée par le listener sur searchField
    }

    @FXML
    private void handleAdd() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/javaa44/AjouterCommentaire.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setTitle("Ajouter un Commentaire");
            stage.setScene(new Scene(root));
            stage.showAndWait();
            loadCommentaires();
        } catch (IOException | SQLException e) {
            showError("Erreur lors de l'ouverture du formulaire d'ajout", e.getMessage());
        }
    }

    @FXML
    private void handleEdit() {
        Commentaire selectedCommentaire = commentaireTable.getSelectionModel().getSelectedItem();
        if (selectedCommentaire == null) {
            showError("Erreur", "Veuillez sélectionner un commentaire à modifier");
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/javaa44/ModifierCommentaire.fxml"));
            Parent root = loader.load();
            ModifierCommentaireController controller = loader.getController();
            controller.setCommentaire(selectedCommentaire);
            
            Stage stage = new Stage();
            stage.setTitle("Modifier le Commentaire");
            stage.setScene(new Scene(root));
            stage.showAndWait();
            loadCommentaires();
        } catch (IOException | SQLException e) {
            showError("Erreur lors de l'ouverture du formulaire de modification", e.getMessage());
        }
    }

    @FXML
    private void handleDelete() {
        Commentaire selectedCommentaire = commentaireTable.getSelectionModel().getSelectedItem();
        if (selectedCommentaire == null) {
            showError("Erreur", "Veuillez sélectionner un commentaire à supprimer");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation de suppression");
        alert.setHeaderText("Supprimer le commentaire");
        alert.setContentText("Êtes-vous sûr de vouloir supprimer ce commentaire ?");

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try {
                commentaireService.deleteCommentaire(selectedCommentaire.getId());
                loadCommentaires();
            } catch (SQLException e) {
                showError("Erreur lors de la suppression", e.getMessage());
            }
        }
    }

    private void showError(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
} 
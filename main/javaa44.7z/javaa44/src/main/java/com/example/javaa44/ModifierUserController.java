package com.example.javaa44;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import java.sql.SQLException;
import java.util.regex.Pattern;

public class ModifierUserController {
    @FXML private TextField nomField;
    @FXML private TextField prenomField;
    @FXML private TextField emailField;
    @FXML private ComboBox<String> roleComboBox;

    private UserService userService = new UserService();
    private User user;
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");

    @FXML
    public void initialize() {
        roleComboBox.getItems().addAll("Admin", "User", "Moderator");
    }

    public void setUser(User user) {
        this.user = user;
        populateFields();
    }

    private void populateFields() {
        if (user != null) {
            nomField.setText(user.getNom());
            prenomField.setText(user.getPrenom());
            emailField.setText(user.getEmail());
            roleComboBox.setValue(user.getRole());
        }
    }

    @FXML
    private void handleSave() {
        if (!validateInputs()) {
            return;
        }

        try {
            user.setNom(nomField.getText().trim());
            user.setPrenom(prenomField.getText().trim());
            user.setEmail(emailField.getText().trim());
            user.setRole(roleComboBox.getValue());

            userService.updateUser(user);
            closeWindow();
        } catch (SQLException e) {
            showError("Erreur lors de la modification de l'utilisateur", e.getMessage());
        }
    }

    @FXML
    private void handleCancel() {
        closeWindow();
    }

    private boolean validateInputs() {
        if (nomField.getText().trim().isEmpty()) {
            showError("Erreur de validation", "Le nom est requis");
            nomField.requestFocus();
            return false;
        }

        if (prenomField.getText().trim().isEmpty()) {
            showError("Erreur de validation", "Le prénom est requis");
            prenomField.requestFocus();
            return false;
        }

        String email = emailField.getText().trim();
        if (email.isEmpty()) {
            showError("Erreur de validation", "L'email est requis");
            emailField.requestFocus();
            return false;
        }

        if (!EMAIL_PATTERN.matcher(email).matches()) {
            showError("Erreur de validation", "Format d'email invalide");
            emailField.requestFocus();
            return false;
        }

        if (roleComboBox.getValue() == null) {
            showError("Erreur de validation", "Le rôle est requis");
            roleComboBox.requestFocus();
            return false;
        }

        return true;
    }

    private void closeWindow() {
        Stage stage = (Stage) nomField.getScene().getWindow();
        stage.close();
    }

    private void showError(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
} 
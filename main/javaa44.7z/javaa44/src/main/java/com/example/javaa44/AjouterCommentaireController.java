package com.example.javaa44;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class AjouterCommentaireController {
    @FXML private TextArea contenuArea;
    @FXML private ComboBox<String> userComboBox;
    @FXML private ComboBox<String> publicationComboBox;

    private CommentaireService commentaireService = new CommentaireService();
    private UserService userService = new UserService();
    private PublicationService publicationService = new PublicationService();

    @FXML
    public void initialize() {
        try {
            loadUsers();
            loadPublications();
        } catch (SQLException e) {
            showError("Erreur lors du chargement des données", e.getMessage());
        }
    }

    private void loadUsers() throws SQLException {
        userComboBox.getItems().clear();
        for (User user : userService.getAllUsers()) {
            userComboBox.getItems().add(user.getNom() + " " + user.getPrenom());
        }
    }

    private void loadPublications() throws SQLException {
        publicationComboBox.getItems().clear();
        for (Publication publication : publicationService.getAllPublications()) {
            publicationComboBox.getItems().add(publication.getTitre());
        }
    }

    @FXML
    private void handleSave() {
        if (!validateInputs()) {
            return;
        }

        try {
            Commentaire commentaire = new Commentaire();
            commentaire.setContenu(contenuArea.getText().trim());
            commentaire.setDate(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            commentaire.setUser(userComboBox.getValue());
            commentaire.setPublication(publicationComboBox.getValue());

            commentaireService.addCommentaire(commentaire);
            closeWindow();
        } catch (SQLException e) {
            showError("Erreur lors de l'ajout du commentaire", e.getMessage());
        }
    }

    @FXML
    private void handleCancel() {
        closeWindow();
    }

    private boolean validateInputs() {
        if (contenuArea.getText().trim().isEmpty()) {
            showError("Erreur de validation", "Le contenu du commentaire est requis");
            contenuArea.requestFocus();
            return false;
        }

        if (userComboBox.getValue() == null) {
            showError("Erreur de validation", "L'utilisateur est requis");
            userComboBox.requestFocus();
            return false;
        }

        if (publicationComboBox.getValue() == null) {
            showError("Erreur de validation", "La publication est requise");
            publicationComboBox.requestFocus();
            return false;
        }

        return true;
    }

    private void closeWindow() {
        Stage stage = (Stage) contenuArea.getScene().getWindow();
        stage.close();
    }

    private void showError(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
} 